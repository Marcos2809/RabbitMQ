#! /bin/bash
echo Initializing Event Manager...
su root -c 
java -cp Release1.jar sensors/TemperatureSensor &
java -cp Release1.jar sensors/HumiditySensor &
java -cp Release1.jar sensors/MovementSensor &
java -cp Release1.jar sensors/DoorSensor &
java -cp Release1.jar sensors/WindowSensor &
java -cp Release1.jar controllers/HumidityController &
java -cp Release1.jar controllers/TemperatureController &
java -cp Release1.jar controllers/SecurityController &
java -jar Release1.jar  
