#! /bin/bash
echo Initializing Event Manager...
su root -c 
java -cp Release3.jar sensors/TemperatureSensor &
java -cp Release3.jar sensors/HumiditySensor &
java -cp Release3.jar sensors/MovementSensor &
java -cp Release3.jar sensors/DoorSensor &
java -cp Release3.jar sensors/WindowSensor &
java -cp Release3.jar controllers/HumidityController &
java -cp Release3.jar controllers/TemperatureController &
java -cp Release3.jar controllers/SecurityController &
java -jar Release3.jar  
