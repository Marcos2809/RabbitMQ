#! /bin/bash
echo Initializing Event Manager...
su root -c 
java -cp Release2.jar sensors/TemperatureSensor &
java -cp Release2.jar sensors/HumiditySensor &
java -cp Release2.jar sensors/MovementSensor &
java -cp Release2.jar sensors/DoorSensor &
java -cp Release2.jar sensors/WindowSensor &
java -cp Release2.jar sensors/FireSensor &
java -cp Release2.jar controllers/HumidityController &
java -cp Release2.jar controllers/TemperatureController &
java -cp Release2.jar controllers/SecurityController &
java -jar Release2.jar  
