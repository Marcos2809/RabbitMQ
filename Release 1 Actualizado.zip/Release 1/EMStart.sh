#! /bin/bash
echo Initializing Event Manager...
su root -c 
java -cp TaskArchi.jar controllers/HumidityController &
java -cp TaskArchi.jar controllers/TemperatureController &
java -cp TaskArchi.jar controllers/SecurityController &
java -cp TaskArchi.jar sensors/TemperatureSensor &
java -cp TaskArchi.jar sensors/HumiditySensor &
java -cp TaskArchi.jar sensors/MovementSensor &
java -cp TaskArchi.jar sensors/DoorSensor &
java -cp TaskArchi.jar sensors/WindowSensor &
java -cp TaskArchi.jar ECSConsole
