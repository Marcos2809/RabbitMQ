#! /bin/bash
echo Initializing Event Manager...
su root -c 
java -cp TaskArchi.jar ECSSecurityConsole
java -jar TaskArchi.jar  
